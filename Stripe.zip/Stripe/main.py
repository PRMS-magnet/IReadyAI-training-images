import stripe
import time
import sendemail
import genkey
import time

# Set your Stripe secret key (test mode)
stripe.api_key = "sk_test_51Qj7QbJIHCEOto5Vt15loPJ0nImNdAgX0oiXOTrr1Ba3GzdqY9CA0GcaNh5fldbjpYL8P0UceITiiWdrUyrXqHg900C4aE8frC"

# Your specific product ID in test mode
SPECIFIC_PRODUCT_ID = "prod_RcO7L1c0MMxWOe"

# File to store processed emails
EMAILS_FILE = "purchased_emails.txt"

api_url = "http://207.246.81.177:8080"  # Ensure the URL matches your running server
api_key = "paGrim-mufyo9-viswos"

# Load existing emails from the file
def load_emails():
    try:
        with open(EMAILS_FILE, "r") as file:
            return set(file.read().splitlines())
    except FileNotFoundError:
        return set()

# Save a new email to the file
def save_email(email):
    with open(EMAILS_FILE, "a") as file:
        file.write(email + "\n")

# Check for new purchases
def check_new_purchases(processed_emails):
    try:
        # Fetch the latest events from Stripe
        events = stripe.Event.list(limit=10)

        for event in events.data:
            # Look for the 'checkout.session.completed' event
            if event["type"] == "checkout.session.completed":
                session = event["data"]["object"]

                # Retrieve the line items to check the purchased product
                line_items = stripe.checkout.Session.list_line_items(session["id"])

                for item in line_items.data:
                    if item["price"]["product"] == SPECIFIC_PRODUCT_ID:
                        email = session["customer_details"]["email"]

                        # Add the email to the list and file only if not already processed
                        if email not in processed_emails:
                            processed_emails.add(email)
                            save_email(email)
                            print(f"New purchase detected! Email: {email}")
                            key = genkey.generate_key_from_server(api_url, email, api_key)
                            sendemail.email_key(key, email)


    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    print("Tracking new purchases...")

    # Load processed emails into a set
    processed_emails = load_emails()

    # Run the script in a loop
    while True:
        check_new_purchases(processed_emails)
        time.sleep(30)  # Check every 30 seconds