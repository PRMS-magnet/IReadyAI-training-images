import requests
import json

BASE_URL = "http://127.0.0.1:5000"

def add_user(email, api_key):
    try:
        # Send the request to add the user
        response = requests.post(f"{BASE_URL}/add_user", json={"email": email, "api_key": api_key})
        
        # Log the raw response for debugging
        print(f"Raw Response: {response.text}")
        
        # Check if the response is in JSON format and handle it
        try:
            response_data = response.json()
            print(f"Add User Response: {response_data}")
            
            # If the request is successful, extract the key
            if "key" in response_data:
                key = response_data["key"]
                print(f"Generated key for user: {key}")
                return key
            else:
                print("Error: No key returned from the server.")
                return None
        except ValueError:
            print(f"Error: Response is not in JSON format. Response text: {response.text}")
            return None
    except Exception as e:
        print(f"Error in add_user: {e}")
        return None

def validate_key(key):
    try:
        response = requests.post(f"{BASE_URL}/validate_key", json={"key": key})
        
        # Log the raw response for debugging
        print(f"Raw Response: {response.text}")
        
        # Check if the response is in JSON format and handle it
        try:
            response_data = response.json()
            print(f"Validate Key Response: {response_data}")
        except ValueError:
            print(f"Error: Response is not in JSON format. Response text: {response.text}")
    except Exception as e:
        print(f"Error in validate_key: {e}")

if __name__ == "__main__":
    email = "jlatala0001@mymail.lausd.net"
    api_key = "paGrim-mufyo9-viswos"  # This is the fixed API key that your server expects
    
    print("Sending request to add user...")
    key = add_user(email, api_key)  # Get the generated key from the server
    
    if key:
        print("Sending request to validate key...")
        validate_key(key)  # Validate the generated key
