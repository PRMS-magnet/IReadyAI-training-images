import requests

def generate_key_from_server(api_url, email, api_key):
    headers = {
        'Content-Type': 'application/json',
    }
    data = {
        'email': email,
        'api_key': api_key
    }

    try:
        response = requests.post(f"{api_url}/add_user", json=data, headers=headers)
        
        # Debugging response
        print(f"Status Code: {response.status_code}")
        print(f"Response Content: {response.text}")

        response_data = response.json()

        if response.status_code == 200:
            print(f"Generated Key: {response_data['key']}")
        else:
            print(f"Error: {response_data.get('error', 'Unknown error occurred')}")
    except requests.exceptions.RequestException as e:
        print(f"Failed to contact server: {e}")
    except ValueError:
        print("Server returned a non-JSON response.")

if __name__ == "__main__":
    api_url = "http://127.0.0.1:5000"  # Update if necessary
    email = "example@example.com"
    api_key = "paGrim-mufyo9-viswos"

    generate_key_from_server(api_url, email, api_key)
