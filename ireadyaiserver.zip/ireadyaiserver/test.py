import requests

BASE_URL = "http://127.0.0.1:5000"

def add_user(email, key):
    response = requests.post(f"{BASE_URL}/add_user", json={"email": email, "key": key})
    print(f"Add User Response: {response.json()}")

def validate_key(key):
    response = requests.post(f"{BASE_URL}/validate_key", json={"key": key})
    print(f"Validate Key Response: {response.json()}")

if __name__ == "__main__":
    email = "user@example.com"
    key = "5913666656"
    
    add_user(email, key)
    validate_key(key)
