from flask import Flask, request, jsonify
from cryptography.fernet import Fernet
from flask_cors import CORS  # Importing CORS for cross-origin support
import logging

app = Flask(__name__)

# Enable CORS
CORS(app)

# Encryption setup for sensitive data
fernet_key = Fernet.generate_key()
cipher_suite = Fernet(fernet_key)

API_KEY = "paGrim-mufyo9-viswos"

# In-memory database for demonstration
main_db = {}  # key: plain key, value: encrypted email

# Enable detailed logging
logging.basicConfig(level=logging.DEBUG)

@app.route('/add_user', methods=['POST'])
def add_user():
    app.logger.debug('Received request for /add_user')
    data = request.get_json()

    app.logger.debug(f'Received data: {data}')
    
    email = data.get('email')
    api_key = data.get('api_key')

    if api_key != API_KEY:
        app.logger.warning(f'Invalid API key: {api_key}')
        return jsonify({'error': 'Invalid API key'}), 403

    if not email:
        app.logger.warning('Missing email')
        return jsonify({'error': 'Missing email'}), 400

    # Generate a new key for the user
    key = Fernet.generate_key().decode()  # Generate a new key
    app.logger.debug(f"Generated key for {email}: {key}")

    # Encrypt email for storage
    encrypted_email = cipher_suite.encrypt(email.encode()).decode()

    # Store the generated key and encrypted email
    main_db[key] = encrypted_email
    app.logger.info(f"User {email} added with key {key}")

    return jsonify({'message': 'User added successfully', 'key': key}), 200

@app.route('/validate_key', methods=['POST'])
def validate_key():
    app.logger.debug('Received request for /validate_key')
    data = request.get_json()

    app.logger.debug(f'Received data: {data}')
    
    key = data.get('key')

    if not key:
        app.logger.warning('No key provided')
        return jsonify({'error': 'No key provided'}), 400

    app.logger.debug(f"Validating key: {key}")

    # Validate the plaintext key directly
    if key in main_db:
        encrypted_email = main_db[key]
        email = cipher_suite.decrypt(encrypted_email.encode()).decode()
        app.logger.info(f"Key {key} is valid, associated email: {email}")
        return jsonify({'email': email}), 200
    else:
        app.logger.warning(f"Invalid key: {key}")
        return jsonify({'error': 'Invalid key'}), 400

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)  # Allow external access
